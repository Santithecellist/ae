﻿
/*
One_Morpher
Author: Mysteropodes
Website: https://www.behance.net/mysteropodes
Description-US: Morpher can be really useful for adjusting the speed and interpolation of many properties at once. It can do this with one simple value graph. It even works for properties that have two and three dimensions.
*/

(function() {  
    
    
    // Get active composition;  
var composition = app.project.activeItem;  
      if (!composition || !(composition instanceof CompItem))  { 
            return alert("Please select composition first");  
    }   

var selectedProperties = composition.selectedProperties; 
var keyState = ScriptUI.environment.keyboardState;
app.beginUndoGroup("Add Keyframes");       
           // Create null
  
if (composition.layer("Control Morpher") == null){

    var myNull=composition.layers.addNull();
        myNull.name="Control Morpher";
    var morpher = myNull.property("ADBE Effect Parade").addProperty("ADBE Slider Control");
    var propEffect =  morpher.property("ADBE Slider Control-0001");
         if (keyState.shiftKey){
            var MorpherName = prompt("Enter text for Morpher:", "Your text");
            morpher.name = MorpherName;
    }else{
            morpher.name = "Morpher";
        }

    var index = 1;

}else{
    
    var ControlLayer = composition.layer("Control Morpher").property("ADBE Effect Parade");
    var newMorpher = ControlLayer.addProperty("ADBE Slider Control");

    var index = ControlLayer.numProperties;
    
    if (keyState.shiftKey){
            var MorpherName = prompt("Enter text for Morpher:", "Your text");
            newMorpher.name = MorpherName;
    }else{
        newMorpher.name = "Morpher"+" "+""+index+"";
        }
    
    var propEffect =  newMorpher.property("ADBE Slider Control-0001");


 }

  var keyState = ScriptUI.environment.keyboardState;  
		var keys = [];
    // For each selected layer  
    for (var i = 0, il = selectedProperties.length; i < il; i++) {  
        
            var srcProp = selectedProperties[i];
		for ( var j= 1; j <= srcProp.numKeys; j++ ) {
			
			var key = getKeyInfo( srcProp, j );
			keys.push( key.time );
		}
        selectedProperties[i].expression = "valueAtTime((thisComp.layer('Control Morpher').effect("+index+")('ADBE Slider Control-0001')-thisComp.displayStartTime/thisComp.frameDuration)*thisComp.frameDuration)";
    }  


  var CompFps = composition.frameRate;
  
  var Minval = valeur_min(keys);
    var KeyMinTime = keys[Minval];
    var KeyMinval = KeyMinTime*CompFps;
    
    setKeyInfo( propEffect, KeyMinTime, KeyMinval );
    
  var Maxval = valeur_max(keys);
    var KeyMaxvalTime = keys[Maxval];
    var KeyMaxval = KeyMaxvalTime*CompFps;
    
      setKeyInfo( propEffect, KeyMaxvalTime, KeyMaxval );
      
    app.endUndoGroup();  
  

})();  
function valeur_max(tableau){


    for (var i = 0, il = tableau.length; i < il; i++) { 
        var a = tableau[i];
            for (var j = 0, jl = tableau.length; j < jl; j++) { 
if (a < tableau[j]) {
    var a = tableau[j];
    var max = j;

    }
}
}
if (max == null) {
    max =0;
    }
    return max;
}
function valeur_min(tableau){


    for (var i = 0, il = tableau.length; i < il; i++) { 
        var a = tableau[i].value;
            for (var j = 0, jl = tableau.length; j < jl; j++) { 
if (a > tableau[j].value) {
    var a = tableau[j];
    var max = j;

    }
}
}
if (max == null) {
    max =0;
    }
    return max;
} 
function setKeyInfo( prop, keyT, keyV ) {


	var index = prop.addKey(keyT);

	prop.setValueAtKey( index, keyV );


}
function getKeyInfo( prop, index ) {

	var key = {}
	var valueType = prop.propertyValueType;

	key.time  = prop.keyTime( index );
	key.value = prop.keyValue( index );

	key.keyInInterpolationType  = prop.keyInInterpolationType( index );
	key.keyOutInterpolationType = prop.keyOutInterpolationType( index );

	if ( valueType == PropertyValueType.TwoD_SPATIAL || valueType == PropertyValueType.ThreeD_SPATIAL ) {

		key.keyInSpatialTangent  = prop.keyInSpatialTangent( index );
		key.keyOutSpatialTangent = prop.keyOutSpatialTangent( index );
		key.keySpatialContinuous = prop.keySpatialContinuous( index );
		key.keySpatialAutoBezier = prop.keySpatialAutoBezier( index );
		key.keyRoving            = prop.keyRoving( index );
	}

	key.keyInTemporalEase     = prop.keyInTemporalEase( index );
	key.keyOutTemporalEase    = prop.keyOutTemporalEase( index );
	key.keyTemporalContinuous = prop.keyTemporalContinuous( index );
	key.keyTemporalAutoBezier = prop.keyTemporalAutoBezier( index );

	return key;
}
